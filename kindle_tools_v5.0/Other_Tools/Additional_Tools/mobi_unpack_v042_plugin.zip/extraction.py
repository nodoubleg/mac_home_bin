#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

__license__   = 'GPL v3'
__docformat__ = 'restructuredtext en'


import os
from functools import partial

from PyQt4.Qt import QMenu, QToolButton
 
from calibre.gui2 import choose_dir, info_dialog, open_local_file
from calibre.gui2.actions import InterfaceAction

from calibre.ptempfile import PersistentTemporaryFile
from calibre_plugins.mobiunpack_plugin.__init__ import (PLUGIN_NAME, 
                                PLUGIN_VERSION, PLUGIN_DESCRIPTION)
import calibre_plugins.mobiunpack_plugin.config as cfg
from calibre_plugins.mobiunpack_plugin.utilities import (get_icon, mobiProcessor,
                                set_plugin_icon_resources, showErrorDlg, topaz,
                                create_menu_item, create_menu_action_unique)


class InterfacePlugin(InterfaceAction):
    name = 'Mobi-unpack'
    action_spec = ('Mobi-unpack', None,
            _(PLUGIN_DESCRIPTION), None)
    popup_type = QToolButton.InstantPopup
    dont_add_to = frozenset(['menubar-device', 'toolbar-device', 'context-menu-device'])
    action_type = 'current'

    def genesis(self):
        self.menu = QMenu(self.gui)
        icon_resources = self.load_resources(cfg.PLUGIN_ICONS)
        set_plugin_icon_resources(cfg.PLUGIN_NAME, icon_resources)
        
        self.qaction.setMenu(self.menu)
        self.qaction.setIcon(get_icon(cfg.PLUGIN_ICONS[0]))
        # Setup hooks so that we only enable the relevant submenus for available formats for the selection.
        self.menu.aboutToShow.connect(self.about_to_show_menu)

    def findFormats(self, db, row):
        # Loop through the ebook's available formats and build a dictionary
        # of the mobi formats containing the format's path and encryption
        # status among other things
        format_data = {}
        if not row.isValid():
            print 'Row not valid'
            return format_data
        self.book_id = book_id = self.gui.library_view.model().id(row)
        print 'Book ID' + str(book_id)
        mobi_formats = ['MOBI', 'AZW', 'AZW4', 'PRC']
        book_formats = db.formats(book_id, index_is_id=True, verify_formats=False)
        if not book_formats:
            print 'No book formats found'
            book_formats = ''
        book_formats = book_formats.split(',')
        for format in book_formats:
            if format in mobi_formats:
                print format
                try:
                    tmp_path = self.gui.library_view.model().db.format_abspath(
                                            book_id, format, index_is_id=True)
                    if tmp_path:
                        if not topaz(str(tmp_path)):
                            mobi = mobiProcessor(str(tmp_path))
                            entry = (tmp_path, mobi.isPrintReplica, mobi.isComboFile, mobi.isEncrypted)
                            format_data[format] = entry
                            tmp_path = None
                except:
                    tmp_path = None
                    pass
        # Return dictionary of all MOBI formats for this book
        return format_data
    
    def update_db(self, pdffile):
        '''
        Update the calibre db with the extracted PDF
        '''
        if not self.gui.library_view.model().db.format_abspath(
                    self.book_id, 'PDF', index_is_id=True):
            current_idx = self.gui.library_view.currentIndex()
            self.gui.library_view.model().db.add_format_with_hooks(self.book_id, 'PDF',
                    pdffile, index_is_id=True, notify=True)
            if current_idx.isValid():
                self.gui.library_view.model().current_changed(current_idx, current_idx)
        else:
            raise Exception(_('A PDF format already exists for this ebook in this library! ' +
                            'MobiUnpack will NOT attempt to overwrite it.\n\n' +
                            'If you want to extract the PDF from the Print Replica ') + '(AZW4)' + _(' format ' +
                            'again, you\'ll need to delete the existing PDF format from ' +
                            'this ebook\'s list of formats.'))

    def directoryChooser(self):
        if cfg.plugin_prefs['Always_Use_Unpack_Folder']:
            return cfg.plugin_prefs['Unpack_Folder']
        else:
            return choose_dir(self.gui, _(PLUGIN_NAME + 'dir_chooser'),
                _('Select Directory To Unpack Mobi To'))
    
    def show_configuration(self):
        self.interface_action_base_plugin.do_user_config(self.gui)
        
    def about_to_show_menu(self):
        db = self.gui.library_view.model().db
        row = self.gui.library_view.currentIndex()
        format_info = self.findFormats(db, row)
        m = self.menu
        m.clear()
        
        # Build the submenus on the fly based on the formats of the ebook
        # selected in the main library view. Unfortunately it can be a bit slow.
        for format, value in format_info.items():
            mnu_img = 'drm-unlocked.png'
            mnu_tip = 'This '+format+' file is DRM-Free.'
            if value[3]:
                print 'isEncrypted = ' + str(value[3])
                mnu_tip = 'This '+format+' file has DRM... can\'t unpack.'
                mnu_img = 'drm-locked.png'
            ac = create_menu_item(self, m, _(format), mnu_img, _(mnu_tip), None)
            sm = QMenu()
            ac.setMenu(sm)
            tool_tip = 'Unpack the MOBI\'s source components'
            unpack_menu = create_menu_action_unique(self, sm, _('&Unpack')+'...', 'images/explode3.png', _(tool_tip),
                                             False, triggered=partial(self.unpack_ebook, value[0]))
            if value[3]:
                unpack_menu.setEnabled(False)
            if value[1]:
                tool_tip = 'Extract the PDF from the Print Replica format and add it to the library.'
                preplica_menu = create_menu_action_unique(self, sm, _('&Extract PDF')+'...', 'images/acrobat.png', _(tool_tip),
                                                 False, triggered=partial(self.print_replica, value[0]))
            if value[2]:
                tool_tip = 'Split the combo KF8/MOBI file into its two components.'
                split_menu = create_menu_action_unique(self, sm, _('&Split KF8/MOBI')+'...', 'edit-cut.png', _(tool_tip),
                                                 False, triggered=partial(self.combo_split, value[0]))
        m.addSeparator()
        tool_tip = 'Configure the Mobi-unpack plugin\'s settings.'
        create_menu_action_unique(self, m, _('&Customize plugin')+'...', 'config.png', _(tool_tip),
                                  None, triggered=self.show_configuration)
        self.gui.keyboard.finalize()
        
    def unpack_ebook(self, path_to_mobi):
        outdir = self.directoryChooser()
        if outdir:
            try:
                mobiProcessor(str(path_to_mobi)).unpackMOBI(str(outdir))
            except Exception, e:
                return showErrorDlg(str(e), self.gui, True)
            open_local_file(outdir)
        
    def print_replica(self, path_to_mobi):
        of = PersistentTemporaryFile('.pdf')
        f = open(of.name, 'wb')
        f.write(mobiProcessor(str(path_to_mobi)).getPDFFile())
        f.close()
        try: 
            self.update_db(of.name)
        except Exception, e:
            return showErrorDlg(str(e), self.gui)
        return info_dialog(None, _(PLUGIN_NAME + ' v' + PLUGIN_VERSION),
            _('<p>PDF successfully extracted and added to Library.'), show=True)
        
    def combo_split(self, path_to_mobi):
        outdir = self.directoryChooser()
        if outdir:
            try:
                mobiProcessor(str(path_to_mobi)).writeSplitCombo(str(outdir))
            except Exception, e:
                return showErrorDlg(str(e), self.gui, True)
            open_local_file(outdir)